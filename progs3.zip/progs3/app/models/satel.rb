class Satel < ActiveRecord::Base
end
