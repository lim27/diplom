class Stat < ActiveRecord::Base
end
