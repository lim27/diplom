class PhraseStat < ActiveRecord::Base
end
