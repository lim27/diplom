class Satellite < ActiveRecord::Base


end
