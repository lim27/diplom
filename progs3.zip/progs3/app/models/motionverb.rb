class Motionverb < ActiveRecord::Base
end
