class Chastotnost < ActiveRecord::Base
end
