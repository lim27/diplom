class Verbstat < ActiveRecord::Base
end
