class Sentence < ActiveRecord::Base
end
