class Verb < ActiveRecord::Base

  validates :present, presence: true
  validates :past_simple, presence: true
  validates :past_partic, presence: true
  validates :third_litco, presence: true

end
