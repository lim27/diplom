class Generatesatel < ActiveRecord::Base
end
