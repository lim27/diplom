class Newtext < ActiveRecord::Base
end
