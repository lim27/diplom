class Text < ActiveRecord::Base
end
