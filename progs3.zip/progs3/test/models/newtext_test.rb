require 'test_helper'

class NewtextTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
