require 'test_helper'

class VerbstatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
