require 'test_helper'

class SatelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
