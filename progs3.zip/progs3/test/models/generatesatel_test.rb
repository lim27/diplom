require 'test_helper'

class GeneratesatelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
