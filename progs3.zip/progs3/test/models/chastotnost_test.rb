require 'test_helper'

class ChastotnostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
