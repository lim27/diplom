require 'test_helper'

class MotionVerbTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
