require 'test_helper'

class VerbTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
