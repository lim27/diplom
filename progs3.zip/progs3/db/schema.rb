# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 0) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "chastotnosts", id: :bigserial, force: :cascade do |t|
    t.integer "id_verb",   limit: 8
    t.text    "righttext"
    t.integer "kol_vo",    limit: 8
  end

  create_table "locations", id: :bigserial, force: :cascade do |t|
    t.text    "location"
    t.integer "ploskost",   limit: 8
    t.integer "vmestilish", limit: 8
  end

  create_table "motionverbs", id: :bigserial, force: :cascade do |t|
    t.text "infinit"
    t.text "past"
    t.text "partic"
  end

  create_table "newtexts", id: :bigserial, force: :cascade do |t|
    t.text    "line"
    t.integer "obrabot", limit: 8
  end

  create_table "phrase_stats", id: :bigserial, force: :cascade do |t|
    t.text "verb_satel"
    t.text "location"
  end

  create_table "satellites", id: :bigserial, force: :cascade do |t|
    t.text    "poslelog"
    t.integer "predloj",  limit: 8
  end

  create_table "satels", id: :bigserial, force: :cascade do |t|
    t.text "slovo"
  end

  create_table "stats", id: :bigserial, force: :cascade do |t|
    t.integer "vsego", limit: 8
  end

  create_table "texts", id: :bigserial, force: :cascade do |t|
    t.text "sentence"
  end

  create_table "verbs", id: :bigserial, force: :cascade do |t|
    t.text "present"
    t.text "past_simple"
    t.text "past_partic"
    t.text "third_litco"
  end

  create_table "verbstats", id: :bigserial, force: :cascade do |t|
    t.text    "verb_satel"
    t.text    "satel"
    t.integer "kol_vo",     limit: 8
  end

end
